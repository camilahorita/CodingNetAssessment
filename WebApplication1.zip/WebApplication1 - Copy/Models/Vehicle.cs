﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace WebApplication1.Models
{
    public class Vehicle
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public Guid Id { get; set; }
        public string Brand { get; set; }
        public string Vin { get; set; }
        public string Color { get; set; }
        public string Year { get; set; }
        public Guid OwnerId { get; set; }

        [JsonIgnore]
        public Owner? Owner { get; set; }

        [JsonIgnore]
        public List<Claim> Claims { get; set; }

    }
}
